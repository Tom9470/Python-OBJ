# Python-OBJ
A simple library for creating basic WaveFront OBJ models from heightmaps stored as 2 dimensional nested lists.
